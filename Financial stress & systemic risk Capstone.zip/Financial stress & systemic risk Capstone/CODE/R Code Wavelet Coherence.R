# Uncomment to install if needed:
# install.packages("tidyverse")
# install.packages("lubridate")
# install.packages("FactoMineR")
# install.packages("factoextra")
# install.packages("missMDA")
# install.packages("biwavelet")

library(tidyverse)
library(lubridate)
library(FactoMineR)
library(factoextra)
library(missMDA)
library(biwavelet)
# Paths to your monthly CSV files
poland_file <- "/Users/thunguyen/Desktop/ThuThu/Monthy Data/Czech Republic_Indicators_Monthly_cleaned_2.csv"
us_file      <- "/Users/thunguyen/Desktop/ThuThu/Monthy Data/United States_Indicators_Monthly_cleaned_2.csv"

# Read Germany
df_pl <- read_csv(poland_file)

# Ensure 'DateTime' column exists and parse it
if (!"DateTime" %in% names(df_pl)) {
  stop("Error: 'DateTime' column missing in Germany CSV!")
}
df_pl <- df_pl %>%
  mutate(DateTime = mdy(DateTime)) %>%  # or ymd() if format is "YYYY-MM-DD"
  arrange(DateTime)

# Read US
df_us <- read_csv(us_file)
if (!"DateTime" %in% names(df_us)) {
  stop("Error: 'DateTime' column missing in US CSV!")
}
df_us <- df_us %>%
  mutate(DateTime = mdy(DateTime)) %>%
  arrange(DateTime)
# Select numeric columns (excluding DateTime)
df_pl_numeric <- df_pl %>%
  select(where(is.numeric))

# Estimate # of components for imputation
ncp_opt_pl <- estim_ncpPCA(df_pl_numeric, scale = TRUE)
cat("Optimal ncp (Poland):", ncp_opt_pl$ncp, "\n")

# Impute missing values
df_pl_imputed <- imputePCA(df_pl_numeric, ncp = ncp_opt_pl$ncp)$completeObs

# PCA
pca_pl <- PCA(df_pl_imputed, scale.unit = TRUE, graph = FALSE)
df_pl$PC1_PL <- pca_pl$ind$coord[, 1]
df_pl$PC2_PL <- pca_pl$ind$coord[, 2]
df_pl$PC3_PL <- pca_pl$ind$coord[, 3]


# US
df_us_numeric <- df_us %>%
  select(where(is.numeric))

ncp_opt_us <- estim_ncpPCA(df_us_numeric, scale = TRUE)
cat("Optimal ncp (US):", ncp_opt_us$ncp, "\n")

df_us_imputed <- imputePCA(df_us_numeric, ncp = ncp_opt_us$ncp)$completeObs
pca_us <- PCA(df_us_imputed, scale.unit = TRUE, graph = FALSE)
df_us$PC1_US <- pca_us$ind$coord[, 1]
df_us$PC2_US <- pca_us$ind$coord[, 2]
df_us$PC3_US <- pca_us$ind$coord[, 3]


df_coherence <- df_pl %>%
  select(DateTime, PC1_PL) %>%
  inner_join(df_us %>% select(DateTime, PC1_US), by = "DateTime")

# Confirm we have monthly frequency and no duplicates
df_coherence <- df_coherence %>%
  arrange(DateTime)


df_coherence <- df_coherence %>%
  mutate(
    Decimal_Year = year(DateTime) + (month(DateTime) - 1) / 12
  )



  

# Prepare PC2 data
df_coherence_pc2 <- df_pl %>%
  select(DateTime, PC2_PL) %>%
  inner_join(df_us %>% select(DateTime, PC2_US), by = "DateTime") %>%
  arrange(DateTime) %>%
  mutate(
    Decimal_Year = year(DateTime) + (month(DateTime) - 1) / 12
  )

# WTC for PC2
wtc_pc2 <- wtc(
  cbind(df_coherence_pc2$Decimal_Year, df_coherence_pc2$PC2_PL),
  cbind(df_coherence_pc2$Decimal_Year, df_coherence_pc2$PC2_US),
  dj        = 0.1,
  s0        = 1/12,
  max.scale = 8,
  mother    = "morlet"
)

plot(
  wtc_pc2,
  main = "Wavelet Coherence: Czech Republic vs. US (PC2)",
  xlab = "Year",
  ylab = "Period (Years)",
  show.siglvl = TRUE,
  coi.col = "gray90"
)
df_coherence_pc3 <- df_pl %>%
  select(DateTime, PC3_PL) %>%
  inner_join(df_us %>% select(DateTime, PC3_US), by = "DateTime") %>%
  arrange(DateTime) %>%
  mutate(
    Decimal_Year = year(DateTime) + (month(DateTime) - 1) / 12
  )

wtc_pc3 <- wtc(
  cbind(df_coherence_pc3$Decimal_Year, df_coherence_pc3$PC3_PL),
  cbind(df_coherence_pc3$Decimal_Year, df_coherence_pc3$PC3_US),
  dj        = 0.1,
  s0        = 1/12,
  max.scale = 8,
  mother    = "morlet"
)

plot(
  wtc_pc3,
  main = "Wavelet Coherence: Czech Republic vs. US (PC3)",
  xlab = "Year",
  ylab = "Period (Years)",
  show.siglvl = TRUE,
  coi.col = "gray90"
)

