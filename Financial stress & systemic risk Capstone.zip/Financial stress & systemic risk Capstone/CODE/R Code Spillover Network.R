# Load necessary libraries
library(tidyverse)
library(lubridate)
library(igraph)

# File paths for each country
datasets <- list(
  "US" = "/Users/thunguyen/Desktop/ThuThu/processed datasets/Extracting datasets/United States_Indicators_Wide.csv",
  "PL" = "/Users/thunguyen/Desktop/ThuThu/processed datasets/Extracting datasets/Poland_Indicators_Wide.csv",
  "NL" = "/Users/thunguyen/Desktop/ThuThu/processed datasets/Extracting datasets/Netherlands_Indicators_Wide.csv",
  "FR" = "/Users/thunguyen/Desktop/ThuThu/processed datasets/Extracting datasets/France_Indicators_Wide.csv",
  "CZ" = "/Users/thunguyen/Desktop/ThuThu/processed datasets/Extracting datasets/Czech Republic_Indicators_Wide.csv",
  "DE" = "/Users/thunguyen/Desktop/ThuThu/processed datasets/Extracting datasets/Germany_Indicators_Wide.csv"
)

# Selected economic indicators
variables <- c("Bank Lending Rate", "Banks Balance Sheet", "Business Confidence", "Personal Savings", "Consumer Confidence")

# Load datasets into a list and convert Quarter column to Date
data_list <- lapply(datasets, function(path) {
  df <- read_csv(path)
  
  # Ensure Quarter is converted to Date format
  df <- df %>%
    mutate(Quarter = str_replace(Quarter, "([0-9]{4})Q([1-4])", "\\1 Q\\2"),  # Add space before 'Q'
           Quarter = yq(Quarter))  # Convert to Date format
  
  return(df)
})

# Merge datasets by Quarter
df_combined <- reduce(names(data_list), function(df, country) {
  df_country <- data_list[[country]] %>%
    select(Quarter, all_of(variables))
  
  # Rename columns to include country name
  colnames(df_country)[-1] <- paste(country, colnames(df_country)[-1], sep = "_")
  
  # Join to the main dataframe
  left_join(df, df_country, by = "Quarter")
}, .init = data_list[[1]] %>% select(Quarter))

# Convert non-numeric columns to numeric (excluding Quarter)
df_combined_numeric <- df_combined %>%
  select(where(is.numeric))

# Compute correlation matrix
corr_matrix <- cor(df_combined_numeric, use = "pairwise.complete.obs")

# Define adjacency matrix based on correlation threshold
threshold <- 0.5
adj_matrix <- ifelse(abs(corr_matrix) > threshold, 1, 0)

# Convert adjacency matrix to graph
graph <- graph_from_adjacency_matrix(adj_matrix, mode = "undirected", diag = FALSE)

V(graph)$centrality <- degree(graph, mode = "all")

# Assign node names
V(graph)$community <- as.factor(membership(cluster_fast_greedy(graph)))


# Install ggraph if not already installed
install.packages("ggraph")

# Load the ggraph library
library(ggraph)
ggraph(graph, layout = "fr") +
  geom_edge_link(aes(alpha = 0.6), color = "gray50") +  # Draw edges
  geom_node_point(aes(size = centrality, color = community)) +  # Nodes sized by centrality
  geom_node_text(aes(label = name), repel = TRUE, size = 4, color = "black") +  # Label nodes
  scale_size(range = c(3, 10)) +  # Adjust node size range
  scale_color_manual(values = c("red", "blue", "green", "purple", "orange", "cyan")) +  # Custom node colors
  theme_void() +  # Remove background
  labs(title = "Financial Stress Network Visualization",
       subtitle = "Nodes represent financial indicators, edges show strong correlations")
# Compute betweenness centrality
V(graph)$betweenness <- betweenness(graph, directed = FALSE)

# Compute eigenvector centrality
V(graph)$eigenvector <- eigen_centrality(graph)$vector

# View top nodes based on centrality measures
top_hubs <- V(graph)[order(-V(graph)$centrality)][1:5]  # Top 5 hubs
top_transmitters <- V(graph)[order(-V(graph)$betweenness)][1:5]  # Top 5 transmitters
top_influencers <- V(graph)[order(-V(graph)$eigenvector)][1:5]  # Most influential nodes

top_hubs
top_transmitters
top_influencers



