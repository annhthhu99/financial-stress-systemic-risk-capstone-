# FEVD Visualization in R using multiple sheets from the Excel file

# Load required libraries
library(tidyverse)
library(readxl)
library(reshape2)
library(ggplot2)

# Load Excel file and read all sheets
fevd_file <- "/Users/thunguyen/Desktop/ThuThu/fevd_all_horizons.xlsx"
sheet_names <- excel_sheets(fevd_file)

# Combine data from all sheets
fevd_combined <- map_dfr(sheet_names, ~{
  data <- read_excel(fevd_file, sheet = .x)
  data_long <- melt(data, id.vars = colnames(data)[1])
  colnames(data_long) <- c("Source", "Target", "Value")
  data_long$Horizon <- .x
  return(data_long)
})

# Aggregate data by source and target across all horizons
fevd_agg <- fevd_combined %>%
  group_by(Source, Target) %>%
  summarize(MeanValue = mean(Value, na.rm = TRUE))

# Create heatmap visualization
heatmap_plot <- ggplot(fevd_agg, aes(x = Target, y = Source, fill = MeanValue)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "white", high = "steelblue") +
  geom_text(aes(label = round(MeanValue, 2)), size = 3, color = "black") +
  labs(title = "Aggregated FEVD Spillover Heatmap",
       x = "Target Country",
       y = "Source Country",
       fill = "Spillover (%)") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(hjust = 0.5))

# Display heatmap
print(heatmap_plot)
